import BaseComponents from "./Component/index.js";

export const Component = BaseComponents;
