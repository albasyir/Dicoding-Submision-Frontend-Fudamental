Saya punya `helper` untuk membuat custom element, sekaligus bahan belajar saya,
untuk helpernya bisa di liat pada folder helper

saya telah menggunakan `customElements.define` pada fungsi `Component.register()`
